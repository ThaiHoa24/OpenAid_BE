import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service.js';
import { Prisma } from '@prisma/client';
import { EventQueryDto } from './dto/index.js';
import { EventStatus } from '../../common/enums/index.js';

@Injectable()
export class EventsRepository {
  constructor(protected readonly prisma: PrismaService) {}

  async create(data: Prisma.EventCreateInput) {
    return this.prisma.event.create({
      data,
      include: {
        roles: true,
        donationNeeds: true,
      },
    });
  }

  async findMany(query: EventQueryDto, isPublic: boolean = true) {
    const where: Prisma.EventWhereInput = {};
    
    if (isPublic) {
      where.status = EventStatus.PUBLISHED;
    }

    if (query.search) {
      where.OR = [
        { title: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.area) {
      where.location = { contains: query.area, mode: 'insensitive' };
    }

    if (query.from || query.to) {
      where.startDate = {};
      if (query.from) where.startDate.gte = new Date(query.from);
      if (query.to) where.startDate.lte = new Date(query.to);
    }

    if (query.itemTypeId) {
      where.donationNeeds = {
        some: {
          itemTypeId: query.itemTypeId,
        },
      };
    }

    return this.prisma.event.findMany({
      where,
      skip: query.skip,
      take: query.take,
      include: {
        organization: {
          select: { id: true, name: true, status: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findById(id: string) {
    return this.prisma.event.findUnique({
      where: { id },
      include: {
        organization: {
          select: { id: true, name: true, status: true },
        },
        roles: true,
        donationNeeds: true,
      },
    });
  }

  async update(id: string, data: Prisma.EventUpdateInput) {
    return this.prisma.event.update({
      where: { id },
      data,
      include: {
        roles: true,
        donationNeeds: true,
      },
    });
  }

  async updateStatus(id: string, status: EventStatus) {
    return this.prisma.event.update({
      where: { id },
      data: { status },
    });
  }

  async delete(id: string) {
    return this.prisma.event.delete({
      where: { id },
    });
  }
}
