import {
  Injectable,
  ForbiddenException,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { EventsRepository } from './events.repository.js';
import { PrismaService } from '../../database/prisma.service.js';
import {
  CreateEventDto,
  UpdateEventDto,
  EventQueryDto,
  ChangeEventStatusDto,
} from './dto/index.js';
import type { AuthenticatedUser } from '../../common/types/authenticated-user.js';
import { EventStatus, OrgStatus, OrganizationRole, TransparencyEntityType } from '../../common/enums/index.js';

@Injectable()
export class EventsService {
  constructor(
    private readonly repository: EventsRepository,
    private readonly prisma: PrismaService,
  ) {}

  private async ensureOrganizer(userId: string, organizationId: string) {
    const membership = await this.prisma.organizationMember.findUnique({
      where: {
        organizationId_userId: { organizationId, userId },
      },
    });

    if (!membership || membership.role !== OrganizationRole.ORGANIZER) {
      throw new ForbiddenException(
        'Bạn phải là Organizer của tổ chức này để thực hiện thao tác.',
      );
    }
    return membership;
  }

  async createEvent(actor: AuthenticatedUser, dto: CreateEventDto) {
    await this.ensureOrganizer(actor.id, dto.organizationId);

    const event = await this.repository.create({
      title: dto.title,
      description: dto.description,
      location: dto.location,
      startDate: new Date(dto.startDate),
      endDate: dto.endDate ? new Date(dto.endDate) : null,
      contactName: dto.contactName,
      contactPhone: dto.contactPhone,
      status: EventStatus.DRAFT,
      organization: { connect: { id: dto.organizationId } },
      roles: dto.volunteerRoles
        ? {
            create: dto.volunteerRoles.map((role) => ({
              name: role.name,
              quantity: role.quantity,
              description: role.description,
            })),
          }
        : undefined,
      donationNeeds: dto.donationNeeds
        ? {
            create: dto.donationNeeds.map((need) => ({
              itemTypeId: need.itemTypeId,
              unitId: need.unitId,
              targetQuantity: need.targetQuantity,
            })),
          }
        : undefined,
    });

    await this.prisma.transparencyLog.create({
      data: {
        entityType: TransparencyEntityType.EVENT,
        entityId: event.id,
        actorId: actor.id,
        newStatus: EventStatus.DRAFT,
        notes: 'Sự kiện được tạo dưới dạng bản nháp',
      },
    });

    return event;
  }

  async getAllEvents(query: EventQueryDto) {
    // Theo FR07, trả về các sự kiện public (đã PUBLISHED)
    return this.repository.findMany(query, true);
  }

  async getEventById(id: string) {
    const event = await this.repository.findById(id);
    if (!event) {
      throw new NotFoundException('Sự kiện không tồn tại.');
    }
    return event;
  }

  async updateEvent(
    actor: AuthenticatedUser,
    id: string,
    dto: UpdateEventDto,
  ) {
    const event = await this.getEventById(id);
    await this.ensureOrganizer(actor.id, event.organizationId);

    if (event.status !== EventStatus.DRAFT) {
      throw new BadRequestException(
        'Chỉ có thể cập nhật thông tin khi sự kiện ở trạng thái DRAFT.',
      );
    }

    return this.repository.update(id, {
      title: dto.title,
      description: dto.description,
      location: dto.location,
      startDate: dto.startDate ? new Date(dto.startDate) : undefined,
      endDate: dto.endDate ? new Date(dto.endDate) : undefined,
      contactName: dto.contactName,
      contactPhone: dto.contactPhone,
    });
  }

  async changeStatus(
    actor: AuthenticatedUser,
    id: string,
    dto: ChangeEventStatusDto,
  ) {
    const event = await this.getEventById(id);
    await this.ensureOrganizer(actor.id, event.organizationId);

    const oldStatus = event.status;
    const newStatus = dto.status;

    if (newStatus === EventStatus.PUBLISHED) {
      if (event.organization.status !== OrgStatus.APPROVED) {
        throw new ForbiddenException(
          'Không thể xuất bản sự kiện! Tổ chức chưa được Admin kích hoạt (status != APPROVED).',
        );
      }
      if (oldStatus !== EventStatus.DRAFT) {
        throw new BadRequestException('Chỉ có thể xuất bản từ bản nháp (DRAFT).');
      }
    } else if (newStatus === EventStatus.CLOSED || newStatus === EventStatus.CANCELLED) {
      if (oldStatus !== EventStatus.PUBLISHED) {
        throw new BadRequestException('Chỉ có thể đóng hoặc hủy sự kiện đang được xuất bản (PUBLISHED).');
      }
    } else if (newStatus === EventStatus.DRAFT) {
      throw new BadRequestException('Không thể chuyển sự kiện về trạng thái DRAFT.');
    }

    const updatedEvent = await this.repository.updateStatus(id, newStatus);

    await this.prisma.transparencyLog.create({
      data: {
        entityType: TransparencyEntityType.EVENT,
        entityId: id,
        actorId: actor.id,
        oldStatus: oldStatus,
        newStatus: newStatus,
        notes: `Cập nhật trạng thái sự kiện sang ${newStatus}`,
      },
    });

    return updatedEvent;
  }

  async deleteDraft(actor: AuthenticatedUser, id: string) {
    const event = await this.getEventById(id);
    await this.ensureOrganizer(actor.id, event.organizationId);

    if (event.status !== EventStatus.DRAFT) {
      throw new BadRequestException(
        'Chỉ có thể xóa sự kiện khi còn ở trạng thái DRAFT. Nếu đã xuất bản, hãy hủy (CANCELLED).',
      );
    }

    return this.repository.delete(id);
  }
}
